import {createStore, combineReducers, applyMiddleware} from 'redux';
//import reducer from './store/client/reducers/reducer.js'
import adminReducers from './admin/reducers/adminReducers'
import clientReducers from './client/reducers/clientReducers'

import thunk from 'redux-thunk'

const rootReducer = combineReducers({
  cRed: clientReducers
});

//const middleware = [thunk]

const store = createStore(rootReducer, applyMiddleware(thunk))

export default store;