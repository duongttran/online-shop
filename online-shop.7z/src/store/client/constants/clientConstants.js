export const FETCH_DATA = 'FETCH_DATA' 
export const FETCH_DATA_FAILED = 'FETCH_DATA_FAILED' 
