import * as clientConstants from '../constants/clientConstants'
import axios from 'axios'

export const fetchDataRequest = () => {
    return dispatch => {
        axios.get("https://606412256bc4d60017fabe06.mockapi.io/product")
        .then((response) => {
            console.log('fetch data from clientActions', response.data)
            dispatch(fetchData(response.data))
        }).catch((error) => {
            console.log('Duongs message from clientActions', error)
            dispatch(fetchDataFailed())
        })
    }
}

export const fetchDataFailed = () => {
    return {
        type: clientConstants.FETCH_DATA_FAILED
    }
}

export const fetchData = (products) => {
    return {
        type: clientConstants.FETCH_DATA, 
        products
    }
}