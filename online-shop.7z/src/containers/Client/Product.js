import React from 'react'


const Product = (props) => {
  return(
    <div>
        Product
        {/* <h3>Name:</h3>
        <img/>
        <p>Quantity:</p>
        <p>Price:</p> */}
    </div>
   )

 }

export default Product