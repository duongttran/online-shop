
import React, { useEffect, useState } from 'react'
import Cart from './Cart'
import ListItem from './ListItem'

import { fetchDataRequest } from '../../store/client/actions/clientActions'
import { connect } from 'react-redux'


const Client = (props) => {
    //let [responseData, setResponseData] = useState([])

    /* const fetchData = () => {
        axios.get("https://606412256bc4d60017fabe06.mockapi.io/product")
        .then((response) => {
            //setResponseData(response.data)
            console.log(response.data)
            products = response.data
        }).catch((error) => {
            console.log(error)
        })
    } */
    const products = []

    useEffect(() => {
        props.fetchAllProducts()
    }, [])

    return (
        <div>
            <p>Client page</p>
            {products.map(item => <p>{item.name}</p>)}
            <ListItem />
        </div>
    )
}

const mapStateToProps = state => {
    console.log("state.cRed.products>>>", state.cRed.products);
    return {
        productList: state.cRed.products,
        error: state.error
    }
}

const mapDispatchToProps = (dispatch, props) => {
    return {
        fetchAllProducts: () => dispatch(fetchDataRequest())
    }
}



export default connect(mapStateToProps, mapDispatchToProps)(Client)