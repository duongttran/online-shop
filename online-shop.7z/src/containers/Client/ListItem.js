import React from 'react'
import Product from './Product'


const ListItem = (props) => {
    return (
      <div>
        ListItem
        <Product />

      </div>
    )
  }

export default ListItem
