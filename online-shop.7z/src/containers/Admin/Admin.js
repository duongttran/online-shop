import React from 'react'

const Admin = (props) => {
  return(
    <div>
        Admin page
    </div>
   )

 }

export default Admin