React router:
npm install--save react - router react - router - dom
import { Link, withRouter } from "react-router-dom";

? withRouter làm nhiệm vụ gì?
?
<Route path="/" exact component={() => <Client />} />
<Route path="/admin" exact component={() => <Admin />} />
<Route path="/client" exact component={() => <Client />} />

? how to completely get rid of the 3rd page?
! absolute and relative path: 199 & 200

// class={`nav-item  ${
//   props.location.pathname === "/about" ? "active" : ""
// }`}


/*  Questions:
1. When use this.props... when use props.... ?


*/

React Redux review:
componnet => dispatches => action => reaches => reducer => updated => central store => trigger => subscription => passed updated state as props

npm install--save react - redux

flow:
//reducer
/* reducer */

import * as actionTypes 
const initialState = {

}

const reducer = (state = initialState, action) => {

    /*  Option 1:
     if (action.type === 'INCREMENT') {
         return {
             count: state.count + 1
         }
     } */

    switch (action.type) {
        case 'INCREMENT':
            const newState = [...state] ? or;
            const newState = Object.assign({}, state)
            newState.counter = state.counter + 1
            return newState
        case INCREMENT: return {
            ...state,
            count: state.count + 1
        }
        case actionTypes.INCREMENT: return {
            ...state,
            count: state.count + 1
        }
        case 'ADD': return { count: state.count + action.val }
    }

    return state
}

// store
/* index.js */
import { createStore, combineReducers, applyMiddleware } from 'redux'
import { Provider } from 'react-redux'
import reducer from './actions'

const rootReducer = combineReducers({
    v1: ...Reducer1
    v2: ...reducer2
})

const logger = (store) => {
    return next => {
        return action => {
            console.log('[Middleware Dispatching]', dispatch)
            const result = next(action);
            console.log('[Middleware] next', store.getState())
            return result
        }
    }
}

const store = createStore(rootReducer, applyMiddleware(logger))

ReactDOM.render(<Provider store={store}><App /></Provider>, ...)

/* in store folder */
/* actions.js */
export const INCREMENT = 'INCREMENT'
...

export const increment = () => {
    return {
        type: INCREMENT
    }
}

export const add = (value) => {
    return {
        type: ADD,
        val: value
    }
}



// DISPATCH 
some other files:
import { connect } from 'react-redux'

import {increment, decrement} from '...actions' //step 1
import * as actionCreators from '...actions' //step 2

const mapStateToProps = state => {
    return {
        ...: state...
    }
}

const mapDispatchToProps = dispatch => {
    return {
        action1: () => dispatch({ type: 'INCREMENT' }) //step 1
        action1: () => dispatch({ type: INCREMENT }) //step 2
        action1: () => dispatch({ type: actionTypes.INCREMENT }) //step 3
        action1: () => dispatch(increment()) //step 4
        action1: () => dispatch(actionCreators.increment()) //step 4

        action2: () => dispatch({ type: 'ADD', val: 10 }) //step 1
        action2: () => dispatch(add(10)) //step 1
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Component)

//subscription